package org.fonteditor.utilities.callback;

public abstract class CallBack {
  public abstract void callback(Object o);
}
