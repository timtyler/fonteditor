package org.fonteditor.elements.paths;

public interface PathConstants {
  int CP_OFFSET = 0x200;
  int CP_SIZE = 0x140 + (CP_OFFSET << 1);
}
