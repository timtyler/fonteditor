package org.fonteditor.elements.paths;

public abstract class ExecutorOnFEPath {
  public abstract void execute(FEPath p, Object o);
}