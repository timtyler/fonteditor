/*
 * Notes:
 * 
 * The main class is "Run.java".  It works for applets or applications.
 * Set org.fonteditor.FEConstants.JAVA_2 in order to access the full range of Java 2 fonts.
 * Press the "Demo" button in the UI to view the "type-and-see" kerning demonstration.
 * "ToDo.java" is the main ToDo list for the project.
 * I haven't included any jar build scripts - but they aren't really needed.
 * 
 * Good luck.
 */
