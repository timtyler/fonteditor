package org.fonteditor.demonstration;

import java.awt.Button;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import org.fonteditor.FEFontRenderer;
import org.fonteditor.editor.grid.QualityChoice;
import org.fonteditor.font.FEFont;
import org.fonteditor.font.FontFind;
import org.fonteditor.font.FontLoad;
import org.fonteditor.graphics.ImageWrapper;
import org.fonteditor.graphics.ImageWrapperTranslated;
import org.fonteditor.gui.FontSelector;
import org.fonteditor.options.GlyphDisplayOptions;
import org.fonteditor.utilities.callback.CallBack;
import org.fonteditor.utilities.log.Log;

/**
  * Type-and-see demonstration application...
  * Inner Panel.
  */

public class DemoPanel extends Panel implements ItemListener, ActionListener {
  //private CharacterGrid character_grid;
  //private int offset_x = 0;
  ///private int offset_y = 0;
  //private TTImage big_image = new TTImage();
  //private Graphics offscreen_graphics;
  //private boolean double_buffering = true;
  //private boolean draw_it;
  //private String edit_character;
  //private char number;
  private TextField textfield_text;
  private TextField textfield_size;
  private Button button_update;
  private GlyphDisplayOptions gdo;
  private FEFontRenderer font_renderer = new FEFontRenderer(this);
  private FEFont font = null;
  private QualityChoice quality_choice;

  public DemoPanel() {
    super();
    init();
  }

  void init() {
    setBackground(Color.white);
    textfield_text = new TextField("The quick brown fox jumped over the lazy dog");
    add(textfield_text);
    FontSelector fsl = new FontSelector(new CallBack() {
      public void callback(Object o) {
        chooseFont((String) o);
      }
    }, this);

    add(new Label("Font:", Label.RIGHT));
    add(fsl.getChoice());
    quality_choice = new QualityChoice(new CallBack() {
      public void callback(Object o) {
        o = o;
        refresh();
      }
    }, new LocalItemListener());
    add(new Label("Quality:", Label.RIGHT));
    add(quality_choice.getChoice());
    textfield_text.addKeyListener(new BKeyListener());
    add(new Label("Size:", Label.RIGHT));
    textfield_size = new TextField("44");
    add(textfield_size);
    button_update = new Button("Update");
    button_update.addActionListener(this);
    add(button_update);
    validate();
    repaint();
  }

  void chooseFont(String s) {
    font = FontFind.find(s, this.getGraphics(), 32, 128, false, false);
    refresh();
  }

  public void paint(Graphics g) {
    update(g);
  }

  //  // test PWD
  //  private void wibble() {
  //  }
  public void update(Graphics g) {
    //Dimension d = getSize();
    //int new_x = d.width;
    //int new_y = d.height;
    g.setColor(Color.white);
    g.fillRect(0, 0, 99999, 99999);
    //g.setColor(Color.red);
    String text = textfield_text.getText();
    //g.drawString(text, 10, 111);
    int siz = Integer.parseInt(textfield_size.getText());
    int quality = quality_choice.getQualityValue();

    if (font == null) {
      font = FontLoad.load("lucky.cff");
    }
    char last_c = '@';
    int x = 4;

    for (int i = 0; i < text.length(); i++) {
      char c = text.charAt(i);

      gdo = font_renderer.getGDO(siz, quality);
      int kd = font_renderer.getKerningDistance(last_c, font, gdo, c, font, gdo);

      x += kd + 2;
      //Log.log("<" + last_c + "> <" + c + "> - " + kd);
      last_c = c;
      ImageWrapperTranslated i_w_t = font_renderer.getCharacterImage(c, font, gdo);
      ImageWrapper i_w = i_w_t.getImageWrapper();

      font_renderer.getCharacterImage(c, font, gdo);
      int offset_y = i_w_t.getOffsetY();

      g.drawImage(i_w.getImage(), x, 40 + offset_y, null);
    }
    //    if ((new_x != gdo.getCoords().getWidth()) || (new_y != gdo.getCoords().getHeight())) {
    //      gdo = gdo.modifySize(new_x, new_y);
    //      //gdo = gdo.modifyAASize(aa_x, aa_y);
    //
    //      Coords c = gdo.getCoords();
    //      CoordsEditor ce = new CoordsEditor(c.getWidth(), c.getHeight(), c.getAAWidth(), c.getAAHeight(), 0, 0);
    //      gdo = gdo.modifyCoords(ce);
    //
    //      draw_it = ((gdo.getCoords().getXScale() > 0) && (gdo.getCoords().getYScale() > 0));
    //      if (draw_it) {
    //        if (double_buffering || ((((CoordsEditor) gdo.getCoords()).getLogAAScaleFactorX() | ((CoordsEditor) gdo.getCoords()).getLogAAScaleFactorY()) != 0)) {
    //
    //          Image _i = createImage(gdo.getCoords().getXScale(), gdo.getCoords().getYScale());
    //
    //          big_image.setImage(_i);
    //        }
    //      }
    //    }
    //
    //    if (draw_it) {
    //      if ((((CoordsEditor) gdo.getCoords()).getLogAAScaleFactorX() | ((CoordsEditor) gdo.getCoords()).getLogAAScaleFactorY()) == 0) {
    //        if (double_buffering) {
    //          offscreen_graphics = big_image.getGraphics();
    //
    //          g.drawImage(big_image.getImage(), offset_x, offset_y, null);
    //        }
    //      } else {
    //        offscreen_graphics = big_image.getGraphics();
    //
    //        big_image.freshImage();
    //
    //        TTImage ti = ImageProcessor.scaleDown(big_image, ((CoordsEditor) gdo.getCoords()).getLogAAScaleFactorX(), ((CoordsEditor) gdo.getCoords()).getLogAAScaleFactorY());
    //        g.drawImage(ti.getImage(), offset_x, offset_y, null);
    //      }
    //    } else {
    //      refresh();
    //    }
  }

  void refresh() {
    gdo = gdo.refresh();
    repaint();
  }

  public void itemStateChanged(ItemEvent e) {
    String state_changed_string = null;

    try {
      if (e != null) {
        state_changed_string = (String) (e.getItem());
        chooseFont(state_changed_string);
      }
    } catch (java.lang.NullPointerException npe) {
      npe.printStackTrace();
    }
  }

  public void actionPerformed(ActionEvent e) {
    // String arg = e.getActionCommand();
    Object source = e.getSource();

    if (source == button_update) {
      refresh();
    }
  }

  class LocalItemListener implements ItemListener {
    public void itemStateChanged(ItemEvent e) {
      e = e;
      refresh();
    }
  }

  // inner class -- for key presses
  class BKeyListener extends KeyAdapter {
    // The user pressed a key corresponding to an ASCII value.
    public void keyTyped(KeyEvent e) {
      char k = e.getKeyChar();

      Log.log("Key:" + k);
      repaint();
    }

    public void keyReleased(KeyEvent e) {
      keyTyped(e);
    }
  }
}