package org.fonteditor.cache;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Image;

import org.fonteditor.font.FEFont;
import org.fonteditor.font.FEGlyph;
import org.fonteditor.graphics.FontImageProcessor;
import org.fonteditor.graphics.ImageWrapper;
import org.fonteditor.graphics.ImageWrapperTranslated;
import org.fonteditor.options.Coords;
import org.fonteditor.options.GlyphDisplayOptions;
import org.fonteditor.utilities.claim.Claim;

/**
 * Cache of multiple glyphs for a specified font and set of display options...
 */

public class FEGlyphCache {
  private static Component component; // hack - could pass it down...?

  private FEFont fefont;
  private GlyphDisplayOptions gdo;
  private CachedGlyph[] cache;
  private int size;

  /**
   * Constructor FEGlyphCache.
   * @param fefont
   * @param gdo
   */
  public FEGlyphCache(FEFont fefont, GlyphDisplayOptions gdo) {
    this.fefont = fefont;
    this.gdo = gdo;
    this.size = fefont.getMax();

    cache = new CachedGlyph[this.size];
  }

  /**
   * Method getGlyphImage.
   * @param c
   * @return TTImage
   */
  //TTImage getGlyphImage(char c) {
  //return getCachedGlyph(c).getImage();
  //}

  /**
   * Method getGlyphImage.
   * @param c
   * @return TTImage
   */
  CachedGlyph getCachedGlyph(char c) {
    if (c >= size) {
      c = '*'; // problems? - if so, use "*".
    }
    if (c < 32) {
      c = '*'; // problems? - if so, use "*".
    }

    if (cache[c] == null) {
      makeGlyph(c);
    }

    return cache[c];
  }

  private void makeGlyph(char c) {
    Coords coords = gdo.getCoords();

    int scale_factor_x = coords.getWidth() / coords.getAAWidth();
    int scale_factor_y = coords.getHeight() / coords.getAAHeight();

    FEGlyph feg = fefont.getGlyphArray().getGlyph(c);

    Claim.claim(feg != null, "FEG = null: [" + c + "] - (" + (int) c + ")");

    //feg.setRemakeFlag();

    ImageWrapper tti = new ImageWrapper(component, coords.getWidth(), coords.getHeight());

    Image i = tti.getImage();
    ImageWrapperTranslated image = null;

    if (i != null) {
      Graphics g = i.getGraphics();

      feg.draw(g, gdo, null);

      //gdo.getCoords().dump();

      //TTImage image = ImageProcessor.scaleDown(tti, log_aa_scale_factor_x, log_aa_scale_factor_y);

      image = FontImageProcessor.fontScale(tti, 1024 / scale_factor_x, 1024 / scale_factor_y);

      cache[c] = new CachedGlyph(image);

      //Log.log("Rendering character:" + (int)c);
    }
  }

  public static void setComponent(Component component) {
    FEGlyphCache.component = component;
  }

  void remove(char c) {
    cache[c] = null;
  }
}
