package org.fonteditor.cache;

import org.fonteditor.graphics.ImageWrapperTranslated;

import org.fonteditor.utilities.general.Utils;

/**
 * Cache of a *particular* glyph...
 */

public class CachedGlyph {
  private static final boolean KERNING_BLUR = true;
  private ImageWrapperTranslated image_wrapper_translated;
  
  private int width = -1;
  private int height = -1;

  private int[] kerning_offsets_lhs = null;
  private int[] kerning_offsets_rhs = null;

  public CachedGlyph(ImageWrapperTranslated image_wrapper_translated) {
    this.image_wrapper_translated = image_wrapper_translated;
  }

  private int getOffset(ImageWrapperTranslated image, int y, int x0, int dx) {
    int[] ia = image.getImageWrapper().getArray();

    getWidth();
    int offset = y * width + x0;

    do {
      if ((ia[offset] & 0xFF) < 0x80) {
        return x0;
      }
      x0 += dx;
      offset += dx;
    } while ((x0 >= 0) && (x0 < width));
    return x0 - dx;
  }

  private int getRHSOffset(ImageWrapperTranslated image, int y) {
    return getOffset(image, y, getWidth() - 1, -1);
  }

  private int getLHSOffset(ImageWrapperTranslated image, int y) {
    return getOffset(image, y, 0, 1);
  }

  public ImageWrapperTranslated getImageWrapperTranslated() {
    return image_wrapper_translated;
  }

  public int getOffsetY() {
    return image_wrapper_translated.getOffsetY();
  }

  public int getWidth() {
    if (width < 0) {
      width = image_wrapper_translated.getImageWrapper().getImage().getWidth(null);
    }
    
    return width;
  }

  public int getHeight() {
    if (height < 0) {
      height = image_wrapper_translated.getImageWrapper().getImage().getHeight(null);
    }
    
    return height;
  }

  public int[] getKerningOffsetsLHS() {
    if (kerning_offsets_lhs == null) {
      getHeight();
      kerning_offsets_lhs = new int[height];
      for (int y = height; --y >= 0;) {
        kerning_offsets_lhs[y] = getLHSOffset(image_wrapper_translated, y);
      }
      
      kerning_offsets_lhs = spreadKerningDataLHS(kerning_offsets_lhs);
    }
    
    return kerning_offsets_lhs;
  }

  public int[] getKerningOffsetsRHS() {
    if (kerning_offsets_rhs == null) {
      getHeight();
      kerning_offsets_rhs = new int[height];
      for (int y = height; --y >= 0;) {
        kerning_offsets_rhs[y] = getRHSOffset(image_wrapper_translated, y);
      }
      
      kerning_offsets_rhs = spreadKerningDataRHS(kerning_offsets_rhs);
    }
    
    return kerning_offsets_rhs;
  }

  private int[] spreadKerningDataRHS(int[] offsets) {
    if (!KERNING_BLUR) {
      return offsets;
    }
    int length = offsets.length;
    int[] new_data = new int[length];

    for (int y = height - 1; --y >= 1;) {
      new_data[y] = Utils.max(offsets[y - 1], offsets[y], offsets[y + 1]);
    }
    
    if (length >= 2) {
      new_data[length - 1] = Utils.max(offsets[length - 1], offsets[length - 2]);
      new_data[0] = Utils.max(offsets[0], offsets[1]);
    }
    
    return new_data;
  }

  private int[] spreadKerningDataLHS(int[] offsets) {
    if (!KERNING_BLUR) {
      return offsets;
    }
    
    int length = offsets.length;
    int[] new_data = new int[length];

    for (int y = height - 1; --y >= 1;) {
      new_data[y] = Utils.min(offsets[y - 1], offsets[y], offsets[y + 1]);
    }
    
    if (length >= 2) {
      new_data[length - 1] = Utils.min(offsets[length - 1], offsets[length - 2]);
      new_data[0] = Utils.min(offsets[0], offsets[1]);
    }
    
    return new_data;
  }
}
