package org.fonteditor.editor.frame;

import org.fonteditor.options.GlyphDisplayOptions;

/**
  * Keeps track of the default display options for a framed Glyph...
  */

public class DefaultFrameDisplayOptions {
  private int width;
  private int height;
  private boolean preserve_aspect_ratio;
  private GlyphDisplayOptions gdo;

  public DefaultFrameDisplayOptions() {
    width = 360;
    height = 780;
    setGdo(new GlyphDisplayOptions());
    preserve_aspect_ratio = true;
  }

  public void setPreserveAspectRatio(boolean preserve_aspect_ratio) {
    this.preserve_aspect_ratio = preserve_aspect_ratio;
  }

  public boolean preservesAspectRatio() {
    return preserve_aspect_ratio;
  }

  public void setHeight(int height) {
    this.height = height;
  }

  public int getHeight() {
    return height;
  }

  public void setWidth(int width) {
    this.width = width;
  }

  public int getWidth() {
    return width;
  }

  public void setGdo(GlyphDisplayOptions gdo) {
    this.gdo = gdo;
  }

  public GlyphDisplayOptions getGDO() {
    return gdo;
  }
}