package org.fonteditor.editor.frame;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Panel;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;

import org.fonteditor.editor.grid.CharacterGrid;
import org.fonteditor.font.FEGlyph;
import org.fonteditor.graphics.FontImageProcessor;
import org.fonteditor.graphics.ImageWrapper;
import org.fonteditor.options.Coords;
import org.fonteditor.options.CoordsEditor;
import org.fonteditor.options.GlyphDisplayOptions;
import org.fonteditor.utilities.log.Log;

/**
  * Inner Panel - containing a single editable Glyph...
  */

public class GlyphInnerPanel extends Panel {
  private static final boolean DOUBLE_BUFFERING = true;

  private static boolean preserve_aspect_ratio = true;

  private CharacterGrid character_grid;
  private Selection selection;

  private int offset_x = 0;
  private int offset_y = 0;

  private Point last_pointer = new Point();
  private Point current_pointer = new Point();
  private boolean mouse_pressed;

  private ImageWrapper big_image = new ImageWrapper();

  private Graphics offscreen_graphics;

  private boolean draw_it;

  private String edit_character;
  private char number;
  private GlyphDisplayOptions gdo;
  private FEGlyph glyph;

  GlyphInnerPanel(String s, CharacterGrid character_grid, DefaultFrameDisplayOptions dfdo) {
    super();
    this.preserve_aspect_ratio = dfdo.preservesAspectRatio();
    this.character_grid = character_grid;
    this.gdo = dfdo.getGDO();
    edit_character = s;
    number = s.charAt(0);
    glyph = character_grid.getFEFont().getGlyphArray().getGlyph(number);
    glyph.resetRemakeFlag();
    selection = new Selection();
  }

  void init() {
    this.addMouseListener(new BMouseListener());
    this.addMouseMotionListener(new BMouseMotionListener());
    this.addKeyListener(new BKeyListener());

    setBackground(Color.white);

    //ActionListener action_listner = new FEActionListener();

    validate();
    repaint();
  }

  public void paint(Graphics g) {
    update(g);
  }

  public void update(Graphics g) {
    Dimension d = getSize();

    int new_x = d.width;
    int new_y = d.height;

    if (preserve_aspect_ratio) {
      if ((new_x << 1) >= new_y) {
        new_x = new_y >> 1;
      }

      if (new_y >= (new_x << 1)) {
        new_y = new_x << 1;
      }
    }

    if ((new_x != gdo.getCoords().getWidth()) || (new_y != gdo.getCoords().getHeight())) {
      if (preserve_aspect_ratio) {
        offset_x = (d.width - new_x) >> 1;
        offset_y = (d.height - new_y) >> 1;

        g.setColor(Color.white);
        g.fillRect(0, 0, 99999, 99999); // overkill...
      } else {
        offset_x = 0;
        offset_y = 0;
      }

      gdo = gdo.modifySize(new_x, new_y);

      Coords c = gdo.getCoords();
      CoordsEditor ce = new CoordsEditor(c.getWidth(), c.getHeight(), c.getAAWidth(), c.getAAHeight(), 0, 0);
      gdo = gdo.modifyCoords(ce);

      glyph.invalidateGraphics(gdo);

      draw_it = ((gdo.getCoords().getXScale() > 0) && (gdo.getCoords().getYScale() > 0));
      if (draw_it) {
        if (DOUBLE_BUFFERING || ((((CoordsEditor) gdo.getCoords()).getLogAAScaleFactorX() | ((CoordsEditor) gdo.getCoords()).getLogAAScaleFactorY()) != 0)) {

          Image image = createImage(gdo.getCoords().getXScale(), gdo.getCoords().getYScale());

          big_image.setImage(image);
        }
      }
    }

    if (draw_it) {
      if ((((CoordsEditor) gdo.getCoords()).getLogAAScaleFactorX() | ((CoordsEditor) gdo.getCoords()).getLogAAScaleFactorY()) == 0) {
        if (DOUBLE_BUFFERING) {
          offscreen_graphics = big_image.getGraphics();

          glyph.draw(offscreen_graphics, gdo, selection);
          g.drawImage(big_image.getImage(), offset_x, offset_y, null);
          //Log.log("g.drawImage(big_image");
        } else {
          glyph.draw(g, gdo, selection);
          //Log.log("feg.draw(g, gdo);");
        }
      } else {
        offscreen_graphics = big_image.getGraphics();

        glyph.draw(offscreen_graphics, gdo, selection);
        big_image.freshImage();

        ImageWrapper ti = FontImageProcessor.scaleDown(big_image, ((CoordsEditor) gdo.getCoords()).getLogAAScaleFactorX(), ((CoordsEditor) gdo.getCoords()).getLogAAScaleFactorY());
        g.drawImage(ti.getImage(), offset_x, offset_y, null);
        //Log.log("drawImage(ti.i...");

        // this seems unnecessary...?
      }
    } else {
      refresh();
    }
  }

  void refresh() {
    gdo = gdo.refresh(); //getCoords().setSize(-99, -99); // immutable...!
    repaint();
  }

  public FEGlyph getFEG() {
    return glyph;
  }

  Point getLastPointer() {
    return last_pointer;
  }

  void setMousePressed(boolean mouse_pressed) {
    this.mouse_pressed = mouse_pressed;
  }

  static void setPreserveAspectRatio(boolean preserve_aspect_ratio) {
    GlyphInnerPanel.preserve_aspect_ratio = preserve_aspect_ratio;
  }

  static boolean preservesAspectRatio() {
    return preserve_aspect_ratio;
  }

  CharacterGrid getCharacterGrid() {
    return character_grid;
  }

  int getOffsetX() {
    return offset_x;
  }

  int getOffsetY() {
    return offset_y;
  }

  void setGDO(GlyphDisplayOptions gdo) {
    this.gdo = gdo;
  }

  GlyphDisplayOptions getGDO() {
    return gdo;
  }

  char getNumber() {
    return number;
  }

  public Selection getSelection() {
    return selection;
  }

  // inner class
  class BMouseListener extends MouseAdapter {
    public void mousePressed(MouseEvent e) {
      if (!mouse_pressed) {
        last_pointer.x = ((CoordsEditor) getGDO().getCoords()).getAAScaleFactorX() * (e.getX() - getOffsetX());
        last_pointer.y = ((CoordsEditor) getGDO().getCoords()).getAAScaleFactorY() * (e.getY() - getOffsetY());

        glyph.select(last_pointer, getGDO(), selection);
        setMousePressed(true);
        GlyphInnerPanel.this.repaint();
        //Log.log("Press");
      }
    }

    public void mouseReleased(MouseEvent e) {
      e = e;

      setMousePressed(false);
      
      if (!glyph.getDragBox()) {
        getCharacterGrid().updateCharacter(getNumber());
      }

      glyph.release(getLastPointer(), getGDO(), selection);

      //Log.log("getNumber:" + getNumber()); /// no work = 256?

      GlyphInnerPanel.this.repaint();
    }
  }

  class FEActionListener implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      e = e;
    }
  }

/**
  * MouseMotionListener class...
  */

  class BMouseMotionListener extends MouseMotionAdapter {
    public void mouseDragged(MouseEvent e) {
      current_pointer.x = ((CoordsEditor) getGDO().getCoords()).getAAScaleFactorX() * (e.getX() - getOffsetX());
      current_pointer.y = ((CoordsEditor) getGDO().getCoords()).getAAScaleFactorY() * (e.getY() - getOffsetY());

      //FEGlyph glyph = getCharacterGrid().getFEFont().getGlyphArray().getGlyph(getNumber());
      glyph.drag(last_pointer, current_pointer, getGDO(), selection);

      last_pointer.x = current_pointer.x;
      last_pointer.y = current_pointer.y;

      GlyphInnerPanel.this.repaint();
      // character_grid.updateCharacter(getGDO(), number);
      //Log.log("Drag");
    }
  }

/**
  * KeyListener  class...
  */

  class BKeyListener extends KeyAdapter {
    // The user pressed a key corresponding to an ASCII value.
    public void keyTyped(KeyEvent e) {
      char k = e.getKeyChar();
      if (k == 'd') {
        Log.log("Delete point");
        GlyphInnerPanel.this.repaint();
      } else if (k == 's') {
        Log.log("Make sraight line");
        GlyphInnerPanel.this.repaint();
      } else if (k == 'b') {
        Log.log("Make bezier");
        GlyphInnerPanel.this.repaint();
      } else if (k == 'a') {
        Log.log("Add point");
        GlyphInnerPanel.this.repaint();
      }
    }
  }

}
