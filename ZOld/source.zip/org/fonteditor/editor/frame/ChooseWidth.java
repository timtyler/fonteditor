package org.fonteditor.editor.frame;

import java.awt.Button;
import java.awt.Checkbox;
import java.awt.Color;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import org.fonteditor.options.GlyphDisplayOptions;

/**
  * GUI component to choose the width of the lines the font is rendered with...
  */

public class ChooseWidth extends Panel {
  private static TextField tf_width;
  private GlyphOuterPanel glyph_outer_panel;
  private Checkbox checkbox_outline;
  private Button button_set;

  public ChooseWidth(final GlyphOuterPanel glyph_outer_panel, GlyphDisplayOptions gdo) {
    this.glyph_outer_panel = glyph_outer_panel;
    ItemListener item_listner = new FEItemListener();
    ActionListener action_listner = new FEActionListener();

    checkbox_outline = new Checkbox("Show outline");
    checkbox_outline.addItemListener(item_listner);
    checkbox_outline.setState(gdo.isOutline());
    add(checkbox_outline);
    add(new Label("Width:"));
    tf_width = new TextField("800");
    add(tf_width);
    button_set = new Button("Set");
    button_set.addActionListener(action_listner);
    add(button_set);
    setBackground(new Color(0xD8D8D8));
    validate();
    repaint();
  }

  void setUpWidth() {
    glyph_outer_panel.getFEGP().setGDO(GlyphDisplayOptions.setWidth(glyph_outer_panel.getFEGP().getGDO(), Integer.parseInt(tf_width.getText())));
    glyph_outer_panel.getFEGP().getFEG().resetRemakeFlag();
    glyph_outer_panel.getFEGP().repaint();
  }

  public Checkbox getCheckboxOutline() {
    return checkbox_outline;
  }

  Button getButtonSet() {
    return button_set;
  }

  GlyphOuterPanel getGlyphOuterPanel() {
    return glyph_outer_panel;
  }

  class FEItemListener implements ItemListener {
    public void itemStateChanged(ItemEvent e) {
      if (e != null) {
        Object o = e.getSource();

        if (o == getCheckboxOutline()) {
          getGlyphOuterPanel().getFEGP().setGDO(GlyphDisplayOptions.setOutline(getGlyphOuterPanel().getFEGP().getGDO(), ((Checkbox) o).getState()));
          getGlyphOuterPanel().getFEGP().getFEG().resetRemakeFlag();
          getGlyphOuterPanel().getFEGP().repaint();
          setUpWidth();
        }
      }
    }
  }

  class FEActionListener implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      // String arg = e.getActionCommand();
      Object source = e.getSource();

      if (source == getButtonSet()) {
        setUpWidth();
      }
    }
  }
}