package org.fonteditor.editor.grid;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import org.fonteditor.gui.TTChoice;
import org.fonteditor.utilities.callback.CallBack;

/**
 * Choose quality of rendering...
 */

public class QualityChoice extends TTChoice implements ItemListener {
  private CallBack call_back;

  public QualityChoice(final CallBack call_back, ItemListener il) {
    super(il);
    this.call_back = call_back;
    add("1", 1);
    add("2", 2);
    add("4", 4);
    add("8", 8);
    add("16", 16);
    getChoice().select("2");
  }

  public int getQualityValue() {
    return stringToNumber(getChoice().getSelectedItem());
  }

  public void itemStateChanged(ItemEvent e) {
    String state_changed_string = null;

    try {
      if (e != null) {
        state_changed_string = (String) (e.getItem());
        call_back.callback(state_changed_string);
      }
    } catch (java.lang.NullPointerException npe) {
      npe.printStackTrace();
    }
  }
}
