package org.fonteditor.utilities.callback;

public abstract class CallBackWithReturn {
  public abstract Object callback(Object o);
}
