package org.fonteditor.font;

import org.fonteditor.options.CoordsConstants;
import org.fonteditor.options.GlyphDisplayOptions;
import org.fonteditor.utilities.general.Utils;

/**
 * Represents a font...
 */

//needs to be immutable...

public class FEFont implements CoordsConstants {
  private static final boolean SHOW_EXTREME_CHARACTERS = false;

  private GlyphArray fega = new GlyphArray(256); // hardwired...

  private int min; // character number...
  private int max; // character number...

  public FEFont(int min, int max) {
    this.min = min;
    this.max = max;
    fega = new GlyphArray(max);
  }

  public void scaleRipped() {
    GlyphDisplayOptions gdo = GlyphDisplayOptions.getGDOForScaling();

    for (int i = min; i < max; i++) {
      FEGlyph glyph = fega.getGlyph(i);

      // Translate...
      int glyph_min_x = glyph.getMinX(gdo);
      glyph.getInstructionStream().translateAll(-glyph_min_x, 0);
      glyph.resetRemakeFlag();
      glyph.resetLastGDO();
    }

    GlyphArray ga = getGlyphArray();

    int min_x = 0; // ga.getMinX(min, max, gdo);
    int min_y = ga.getMinY(min, max, gdo);
    int max_x = ga.getMaxX(min, max, gdo);
    int max_y = ga.getMaxY(min, max, gdo);

    if (SHOW_EXTREME_CHARACTERS) {
      ga.showCharsWithY(min, max, min_y, gdo);
      ga.showCharsWithY(min, max, max_y, gdo);
      ga.showCharsWithX(min, max, max_x, gdo);
    }

    float x_factor = (float) FACTOR_X / (float) (max_x - min_x);
    float y_factor = (float) FACTOR_Y / (float) (max_y - min_y);
    float factor = Utils.min(x_factor, y_factor);

    for (int i = min; i < max; i++) {
      FEGlyph glyph = fega.getGlyph(i);

      glyph.getInstructionStream().translateAll(0, -min_y); // move the IS...

      // Rescale...
      glyph.getInstructionStream().scaleAll(factor, factor); // rescale the IS...

      glyph.resetRemakeFlag();
      glyph.resetLastGDO();
    }
  }

  public int getMax() {
    return max;
  }

  int getMin() {
    return min;
  }

  public GlyphArray getGlyphArray() {
    return fega;
  }
}
