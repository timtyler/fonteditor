package org.fonteditor.gui;

import java.awt.Checkbox;
import java.awt.Color;
import java.awt.Label;
import java.awt.Panel;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import org.fonteditor.utilities.callback.CallBack;

public class PanelFontSelector extends Panel implements ItemListener {
  private static Checkbox checkbox_bold;
  private static Checkbox checkbox_italic;
  private FontSelector font_selector;
  private CallBack call_back;

  public PanelFontSelector(final CallBack call_back, boolean styles) {
    this.call_back = call_back;
    add(new Label("Font:", Label.RIGHT));
    font_selector = new FontSelector(call_back, this);
    add(font_selector.getChoice());

    checkbox_bold = new Checkbox("Bold");
    checkbox_bold.addItemListener(this);

    if (styles) {
      add(checkbox_bold);
    }

    getCheckboxBold().setState(true);
    checkbox_italic = new Checkbox("Italic");
    checkbox_italic.addItemListener(this);

    if (styles) {
      add(checkbox_italic);
    }

    //add(new Label("Size:"));
    //tf_size = new TextField("256");
    //add(tf_size);

    setBackground(new Color(0xE8E8E8));
    validate();
    repaint();
  }

  public void itemStateChanged(ItemEvent e) {
    e = e;
    //String state_changed_string = null;

    call_back.callback(font_selector.getSelectedItem());
  }

  public Checkbox getCheckboxBold() {
    return checkbox_bold;
  }

  public Checkbox getCheckboxItalic() {
    return checkbox_italic;
  }

  public FontSelector getFontSelector() {
    return font_selector;
  }
}
