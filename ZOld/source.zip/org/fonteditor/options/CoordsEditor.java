package org.fonteditor.options;

import org.fonteditor.utilities.log.Log;

/**
 * Specialised version of the Coords class for use in the editor...
 * You'll need to use this class if using the renderer...
 */

public class CoordsEditor extends Coords {
  private int log_aa_scale_factor_x;
  private int log_aa_scale_factor_y;
  private int aa_scale_factor_x;
  private int aa_scale_factor_y;

  public CoordsEditor(int x, int y, int aa_x, int aa_y, int log_aa_scale_factor_x, int log_aa_scale_factor_y) {
    super(x, y, aa_x, aa_y);
    setAntiAliasing(log_aa_scale_factor_x, log_aa_scale_factor_y);
    setSizeInternal(x, y);
    setAASizeInternal(aa_x, aa_y);
  }

  void setSizeInternal(int x, int y) {
    super.setSizeInternal(x, y);
    setXScale(getWidth() * aa_scale_factor_x);
    setYScale(getHeight() * aa_scale_factor_y);
  }

  public Coords setAASize(int x, int y) {
    return new CoordsEditor(getWidth(), getHeight(), x, y, log_aa_scale_factor_x, log_aa_scale_factor_y);
  }

  private void setAntiAliasing(int aax, int aay) {
    log_aa_scale_factor_x = aax;
    log_aa_scale_factor_y = aay;
    aa_scale_factor_x = 1 << aax;
    aa_scale_factor_y = 1 << aay;
  }

  public int getAAScaleFactorX() {
    return aa_scale_factor_x;
  }

  public int getAAScaleFactorY() {
    return aa_scale_factor_y;
  }

  public int getLogAAScaleFactorX() {
    return log_aa_scale_factor_x;
  }

  public int getLogAAScaleFactorY() {
    return log_aa_scale_factor_y;
  }

  protected Object clone() throws CloneNotSupportedException {
    return new CoordsEditor(getWidth(), getHeight(), getAAWidth(), getAAHeight(), log_aa_scale_factor_x, log_aa_scale_factor_y);
  }

  Coords modifyAASize(int x, int y) {
    return new CoordsEditor(getWidth(), getHeight(), x, y, log_aa_scale_factor_x, log_aa_scale_factor_y);
  }

  Coords modifySize(int x, int y) {
    return new CoordsEditor(x, y, getAAWidth(), getAAHeight(), log_aa_scale_factor_x, log_aa_scale_factor_y);
  }

  void dump() {
    super.dump();
    Log.log("log_aa_scale_factor_x:" + log_aa_scale_factor_x);
    Log.log("log_aa_scale_factor_y:" + log_aa_scale_factor_y);
    Log.log("aa_scale_factor_x:" + aa_scale_factor_x);
    Log.log("aa_scale_factor_y:" + aa_scale_factor_y);
  }
}

  //  private void antiAliasingOff() {
  //    setAntiAliasing(0, 0);
  //  }
  //
  //  private void antiAliasingOn() {
  //    setAntiAliasing(1, 1);
  //  }
