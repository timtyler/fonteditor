package org.fonteditor.options;

import org.fonteditor.utilities.log.Log;

/**
 * Coordinate system...
 * You'll need to use this class if using the renderer...
 */

public class Coords implements CoordsConstants, Cloneable {
  private int one_pixel_width; // derived...
  private int one_pixel_height; // derived...
  private int x_scale = -1; // derived...
  private int y_scale = -1; // derived...
  private int width = -1;
  private int height = -1;
  private int aa_width; // result after anti-aliasing...
  private int aa_height; // result after anti-aliasing...
  private int aa_dx; // derived...
  private int aa_dy; // derived...

  //----------------------------------------------------------------------------
  public Coords(int x, int y, int aa_x, int aa_y) {
    setSizeInternal(x, y);
    setAASizeInternal(aa_x, aa_y);
  }

  void setSizeInternal(int x, int y) {
    this.width = x;
    this.height = y;
    x_scale = width;
    y_scale = height;
    one_pixel_width = FACTOR_X / this.width;
    one_pixel_height = FACTOR_Y / this.height;
  }

  void setAASizeInternal(int x, int y) {
    aa_width = x;
    aa_height = y;
    aa_dx = FACTOR_X / x;
    aa_dy = FACTOR_Y / y;
  }

  public Coords setAASize(int x, int y) {
    return new Coords(width, height, x, y);
  }

  // 0000-FFFF -> pixels
  public int scaleX(int x) {
    return (x * x_scale) >> LOG_FACTOR_X;
  }

  // 0000-FFFF -> pixels
  public int scaleY(int y) {
    return (y * y_scale) >> LOG_FACTOR_Y;
  }

  // pixels -> 0000-FFFF
  public int rescaleX(int x) {
    return (x << LOG_FACTOR_X) / x_scale;
  }

  // pixels -> 0000-FFFF
  public int rescaleY(int y) {
    return (y << LOG_FACTOR_Y) / y_scale;
  }

  public int nearestX(int x, int v) {
    x += (aa_dx >> 1) + v;
    return (((x * aa_width) & MASK_X) / aa_width) - v;
  }

  public int nearestY(int y, int v) {
    y += (aa_dy >> 1) + v;
    return (((y * aa_height) & MASK_Y) / aa_height) - v;
  }

  public int getAAHeight() {
    return aa_height;
  }

  public int getAAWidth() {
    return aa_width;
  }

  public int getHeight() {
    return height;
  }

  int getOnePixelHeight() {
    return one_pixel_height;
  }

   int getOnePixelWidth() {
    return one_pixel_width;
  }

  public int getWidth() {
    return width;
  }

  public int getXScale() {
    return x_scale;
  }

  public int getYScale() {
    return y_scale;
  }

  protected Object clone() throws CloneNotSupportedException {
    return new Coords(width, height, aa_width, aa_height);
  }

  Coords refresh() {
    return modifySize(-99, -99);
  }

  Coords modifyAASize(int x, int y) {
    return new Coords(width, height, x, y);
  }

  Coords modifySize(int x, int y) {
    return new Coords(x, y, aa_width, aa_height);
  }

  void dump() {
    Log.log("width:" + width);
    Log.log("height:" + height);
    Log.log("aa_width:" + aa_width);
    Log.log("aa_height:" + aa_height);
  }

  public void setXScale(int x_scale) {
    this.x_scale = x_scale;
  }

  public void setYScale(int y_scale) {
    this.y_scale = y_scale;
  }

  void setAAWidth(int aa_width) {
    this.aa_width = aa_width;
  }

  void setAAHeight(int aa_height) {
    this.aa_height = aa_height;
  }
}

  //  private int nearestX(int x) {
  //    x += (aa_dx >> 1);
  //
  //    return ((x * aa_width) & MASK_X) / aa_width;
  //  }
  //
  //  private int nearestY(int y) {
  //    y += (aa_dy >> 1);
  //
  //    return ((y * aa_height) & MASK_Y) / aa_height;
  //  }
  
 //protected
  //  protected void antiAliasingOff() {
  //    setAntiAliasing(0, 0);
  //  }
  //
  //  protected void antiAliasingOn() {
  //    setAntiAliasing(1, 1);
  //  }
  //
  //  protected void setAntiAliasing(int aax, int aay) {
  //    log_aa_scale_factor_x = aax;
  //    log_aa_scale_factor_y = aay;
  //    aa_scale_factor_x = 1 << aax;
  //    aa_scale_factor_y = 1 << aay;
  //  }

//  public static int getFactorX() {
//    return FACTOR_X;
//  }
//
//  public static int getFactorY() {
//    return FACTOR_Y;
//  }
//
//  private static int getLogFactorX() {
//    return LOG_FACTOR_X;
//  }
//
//  private static int getLogFactorY() {
//    return LOG_FACTOR_Y;
//  }
//
//  private static int getMaskX() {
//    return MASK_X;
//  }
//
//  private static int getMaskY() {
//    return MASK_Y;
//  }
