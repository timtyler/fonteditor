package org.fonteditor.options;

/**
 * DisplayOptions for each glyph...
 * You'll need to use this class if using the renderer...
 */

//needs to be immutable...

public class GlyphDisplayOptions implements Cloneable {
  private boolean show_sliders = true;
  private boolean show_grid = true;
  private boolean hint = true;
  private boolean outline = true;
  private boolean fill = true;
  private boolean border = false;
  private boolean show_points = false;
  private boolean show_springs = true;
  private int width = 0x300;
  private Coords coords;
  private static boolean default_show_sliders = true;
  private static boolean default_show_grid = true;
  private static boolean default_hint = true;
  private static boolean default_outline = true;
  private static boolean default_fill = true;
  private static boolean default_border = true;
  private static boolean default_show_points = true;
  private static boolean default_show_springs = false;
  private static int default_width = 0x300;
  private static Coords default_coords = new Coords(40, 40, 12, 20);

  public GlyphDisplayOptions(boolean show_sliders, boolean show_grid, boolean hint, boolean outline, boolean fill, boolean border, boolean show_points, boolean show_springs, int width, Coords coords) {
    set(show_sliders, show_grid, hint, outline, fill, border, show_points, show_springs, width, coords);
  }

  public GlyphDisplayOptions() {
    set(default_show_sliders, default_show_grid, default_hint, default_outline, default_fill, default_border, default_show_points, default_show_springs, default_width, default_coords);
  }

  private void set(boolean show_sliders, boolean show_grid, boolean hint, boolean outline, boolean fill, boolean border, boolean show_points, boolean show_springs, int width, Coords coords) {
    this.show_sliders = show_sliders;
    this.show_grid = show_grid;
    this.hint = hint;
    this.outline = outline;
    this.fill = fill;
    this.border = border;
    this.show_points = show_points;
    this.show_springs = show_springs;
    this.width = width;
    this.coords = coords;
  }

  public static GlyphDisplayOptions getGDOForScaling() {
    return new GlyphDisplayOptions(default_show_sliders, default_show_grid, false, default_outline, default_fill, false, false, false, default_width, default_coords);
  }

  private static GlyphDisplayOptions getGDOdefaults() {
    return new GlyphDisplayOptions(default_show_sliders, default_show_grid, default_hint, default_outline, default_fill, false, false, false, default_width, default_coords);
  }

  public static GlyphDisplayOptions getGDOrender(int siz, int aa_sf_x, int aa_sf_y) {
    Coords c = new Coords((siz >> 1) * aa_sf_x, siz * aa_sf_y, siz >> 1, siz);

    return new GlyphDisplayOptions(false, false, true, false, true, false, false, false, 0, c);
  }

  public static GlyphDisplayOptions setShowSliders(GlyphDisplayOptions gdo, boolean show_sliders) {
    GlyphDisplayOptions next = null;

    try {
      next = (GlyphDisplayOptions) gdo.clone();
    } catch (CloneNotSupportedException e) {
      e.printStackTrace();
    }
    next.show_sliders = show_sliders;
    return next;
  }

  public static GlyphDisplayOptions setShowGrid(GlyphDisplayOptions gdo, boolean show_grid) {
    GlyphDisplayOptions next = null;

    try {
      next = (GlyphDisplayOptions) gdo.clone();
    } catch (CloneNotSupportedException e) {
      e.printStackTrace();
    }
    next.show_grid = show_grid;
    return next;
  }

  public static GlyphDisplayOptions setHint(GlyphDisplayOptions gdo, boolean hint) {
    GlyphDisplayOptions next = null;

    try {
      next = (GlyphDisplayOptions) gdo.clone();
    } catch (CloneNotSupportedException e) {
      e.printStackTrace();
    }
    next.hint = hint;
    return next;
  }

  public static GlyphDisplayOptions setOutline(GlyphDisplayOptions gdo, boolean outline) {
    GlyphDisplayOptions next = null;

    try {
      next = (GlyphDisplayOptions) gdo.clone();
    } catch (CloneNotSupportedException e) {
      e.printStackTrace();
    }
    next.outline = outline;
    return next;
  }

  public static GlyphDisplayOptions setFill(GlyphDisplayOptions gdo, boolean fill) {
    GlyphDisplayOptions next = null;

    try {
      next = (GlyphDisplayOptions) gdo.clone();
    } catch (CloneNotSupportedException e) {
      e.printStackTrace();
    }
    next.fill = fill;
    return next;
  }

  public static GlyphDisplayOptions setBorder(GlyphDisplayOptions gdo, boolean border) {
    GlyphDisplayOptions next = null;

    try {
      next = (GlyphDisplayOptions) gdo.clone();
    } catch (CloneNotSupportedException e) {
      e.printStackTrace();
    }
    next.border = border;
    return next;
  }

  public static GlyphDisplayOptions setShowPoints(GlyphDisplayOptions gdo, boolean show_points) {
    GlyphDisplayOptions next = null;

    try {
      next = (GlyphDisplayOptions) gdo.clone();
    } catch (CloneNotSupportedException e) {
      e.printStackTrace();
    }
    next.show_points = show_points;
    return next;
  }

  public static GlyphDisplayOptions setShowSprings(GlyphDisplayOptions gdo, boolean show_springs) {
    GlyphDisplayOptions next = null;

    try {
      next = (GlyphDisplayOptions) gdo.clone();
    } catch (CloneNotSupportedException e) {
      e.printStackTrace();
    }
    next.show_springs = show_springs;
    return next;
  }

  public static GlyphDisplayOptions setWidth(GlyphDisplayOptions gdo, int width) {
    GlyphDisplayOptions next = null;

    try {
      next = (GlyphDisplayOptions) gdo.clone();
    } catch (CloneNotSupportedException e) {
      e.printStackTrace();
      e.printStackTrace();
    }
    next.width = width;
    return next;
  }

  public static GlyphDisplayOptions setCoords(GlyphDisplayOptions gdo, Coords coords) {
    GlyphDisplayOptions next = null;

    try {
      next = (GlyphDisplayOptions) gdo.clone();
    } catch (CloneNotSupportedException e) {
      e.printStackTrace();
    }
    next.coords = coords;
    return next;
  }

  public int getLineWidthOffsetEast() {
    return 0 - (coords.getOnePixelWidth() >> 1) + (outline ? width : 0); // OK
  }

  public int getLineWidthOffsetWest() {
    return 0 - (coords.getOnePixelWidth() >> 2) + (outline ? -width : 0); // OK
  }

  public int getLineWidthOffsetNorth() {
    return 0 - (coords.getOnePixelHeight() >> 2) + (outline ? -width : 0);
  }

  public int getLineWidthOffsetSouth() {
    return 0 - (coords.getOnePixelHeight() >> 1) + (outline ? width : 0);
  }

  //  public boolean equals(Object o) {
  //    FEGlyphDisplayOptions gdo = (FEGlyphDisplayOptions) o;
  //
  //    Log.log("testeq");
  //
  //    if (show_sliders != gdo.show_sliders) {
  //      return false;
  //    }
  //
  //    return true;
  //  }

  /**
   * Returns the c.
   * @return Coords
   */
  public Coords getCoords() {
    return coords;
  }

  /**
   * Returns the fill.
   * @return boolean
   */
  public boolean isFill() {
    return fill;
  }

  /**
   * Returns the hint.
   * @return boolean
   */
  public boolean isHint() {
    return hint;
  }

  /**
   * Returns the outline.
   * @return boolean
   */
  public boolean isOutline() {
    return outline;
  }

  /**
   * Returns the show_grid.
   * @return boolean
   */
  public boolean isShowGrid() {
    return show_grid;
  }

  /**
   * Returns the show_points.
   * @return boolean
   */
  public boolean isShowPoints() {
    return show_points;
  }

  /**
   * Returns the show_sliders.
   * @return boolean
   */
  public boolean isShowSliders() {
    return show_sliders;
  }

  /**
   * Returns the show_springs.
   * @return boolean
   */
  public boolean isShowSprings() {
    return show_springs;
  }

  /**
   * Returns the width.
   * @return int
   */
  public int getWidth() {
    return width;
  }

  /**
   * Returns the border.
   * @return boolean
   */
  public boolean isBorder() {
    return border;
  }

  protected Object clone() throws CloneNotSupportedException {
    // super.clone();
    return new GlyphDisplayOptions(show_sliders, show_grid, hint, outline, fill, border, show_points, show_springs, width, (Coords) coords.clone());
  }

  /**
   * Method refresh.
   * @return FEGlyphDisplayOptions
   */
  public GlyphDisplayOptions refresh() {
    Coords c = coords.refresh();

    return setCoords(this, c);
  }

  /**
   * Method setSize.
   * @param d
   * @return FEGlyphDisplayOptions
   */
  public GlyphDisplayOptions modifySize(int x, int y) {
    Coords c = coords.modifySize(x, y);

    return setCoords(this, c);
  }

  //  /**
  //   * Method setSize.
  //   * @param d
  //   * @return FEGlyphDisplayOptions
  //   */
  //  public FEGlyphDisplayOptions modifyEditorSize(int x, int y) {
  //    CoordsEditor c = coords.modifySize(x, y);
  //
  //    return setCoords(this, c);
  //  }

  /**
   * Method setSize.
   * @param d
   * @return FEGlyphDisplayOptions
   */
  public GlyphDisplayOptions modifyAASize(int x, int y) {
    Coords c = coords.modifyAASize(x, y);

    return setCoords(this, c);
  }

  //  /**
  //   * Method dump.
  //   */
  //  private void dump() {
  //    Log.log("show_sliders:" + show_sliders);
  //    Log.log("show_grid:" + show_grid);
  //    Log.log("hint:" + hint);
  //    Log.log("outline:" + outline);
  //    Log.log("fill:" + fill);
  //    Log.log("border:" + border);
  //    Log.log("show_points:" + show_points);
  //    Log.log("show_springs:" + show_springs);
  //    Log.log("width:" + width);
  //    //Log.log("coords:" + coords);
  //  }

  /**
   * Method modifyCoords.
   * @param ce
   * @return FEGlyphDisplayOptions
   */
  public GlyphDisplayOptions modifyCoords(CoordsEditor ce) {
    return setCoords(this, ce);
  }
}