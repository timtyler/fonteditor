package org.fonteditor.springs;

public interface SpringConstants {
  static final boolean USE_SPRINGS = false;
}
